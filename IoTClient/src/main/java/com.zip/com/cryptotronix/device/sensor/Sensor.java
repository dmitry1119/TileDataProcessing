/**
 * 
 */
package com.cryptotronix.device.sensor;

/**
 * @author Josh Datko <jbd@cryptotronix.com>
 *
 */
public interface Sensor {
	
	public String getData();

}
