package com.tilepay.domain.entity;

public enum CurrencyEnum {
    BTC, TILECOINX;
}
