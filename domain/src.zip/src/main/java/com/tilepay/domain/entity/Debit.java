package com.tilepay.domain.entity;

import javax.persistence.Entity;

@Entity
public class Debit extends LedgerEntry {
}
