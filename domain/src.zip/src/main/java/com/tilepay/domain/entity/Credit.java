package com.tilepay.domain.entity;

import javax.persistence.Entity;

@Entity
public class Credit extends LedgerEntry {
}
