package com.tilepay.domain.entity;

public interface Builder<T> {
    T build();
}
