package com.tilepay.domain.entity;

public enum IssuanceStatus {
    FEE_IS_NOT_CHARGED,
    CREATED
}
